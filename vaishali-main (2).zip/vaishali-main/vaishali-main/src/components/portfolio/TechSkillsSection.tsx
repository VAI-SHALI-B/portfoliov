import { useScrollAnimation } from '@/hooks/useScrollAnimation';

const TechSkillsSection = () => {
  const { ref, isVisible } = useScrollAnimation();

  const techSkills = [
    { name: 'Python', level: 95 },
    { name: 'C', level: 85 },
    { name: 'C++', level: 85 },
    { name: 'Java', level: 75 },
    { name: 'HTML & CSS', level: 70 },
  ];

  return (
    <section id="tech-skills" className="section-spacing bg-muted/30" ref={ref}>
      <div className="container mx-auto px-8">
        <div className={`transition-all duration-700 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          <h2 className="font-heading text-3xl md:text-4xl text-accent mb-16 text-center">
            Technical Proficiency
          </h2>

          <div className="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {techSkills.map((skill, index) => (
              <div
                key={skill.name}
                className="elevated-card p-6 flex flex-col items-center"
                style={{ transitionDelay: `${index * 100}ms` }}
              >
                {/* Circular Progress */}
                <div className="relative w-24 h-24 mb-4">
                  <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                    {/* Background circle */}
                    <circle
                      cx="50"
                      cy="50"
                      r="40"
                      fill="none"
                      stroke="hsl(var(--muted))"
                      strokeWidth="8"
                    />
                    {/* Progress circle */}
                    <circle
                      cx="50"
                      cy="50"
                      r="40"
                      fill="none"
                      stroke="url(#gradient)"
                      strokeWidth="8"
                      strokeLinecap="round"
                      strokeDasharray={`${skill.level * 2.51} 251`}
                      className="transition-all duration-1000 ease-out"
                      style={{
                        strokeDasharray: isVisible ? `${skill.level * 2.51} 251` : '0 251',
                      }}
                    />
                    <defs>
                      <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                        <stop offset="0%" stopColor="hsl(var(--primary))" />
                        <stop offset="100%" stopColor="hsl(var(--secondary))" />
                      </linearGradient>
                    </defs>
                  </svg>
                  <span className="absolute inset-0 flex items-center justify-center text-accent font-heading text-xl">
                    {skill.level}%
                  </span>
                </div>
                <h3 className="text-foreground font-body font-medium">{skill.name}</h3>
              </div>
            ))}

            {/* AI/ML - No meter */}
            <div className="elevated-card p-6 flex flex-col items-center justify-center">
              <div className="w-24 h-24 mb-4 flex items-center justify-center">
                <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center animate-glow-pulse">
                  <span className="text-secondary text-2xl">✦</span>
                </div>
              </div>
              <h3 className="text-foreground font-body font-medium">Basics of AI/ML</h3>
              <p className="text-muted-foreground text-xs mt-2">Exploring</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TechSkillsSection;
