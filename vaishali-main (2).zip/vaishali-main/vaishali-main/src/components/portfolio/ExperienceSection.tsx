import { useScrollAnimation } from '@/hooks/useScrollAnimation';

const ExperienceSection = () => {
  const { ref, isVisible } = useScrollAnimation();

  const experiences = [
    {
      title: 'Gravitas 2025',
      role: 'Organizing Team',
      points: [
        'Managed activities from expo to final event',
        'Coordinated technical + creative segments',
        'Ensured smooth participant flow and team alignment',
      ],
    },
    {
      title: 'Friendship Day 2025',
      role: 'Organizing Team',
      points: [
        'Managed stall and coordinated interactions',
        'Handled crowd flow and game setup',
        'Ensured engaging participant experience',
      ],
    },
    {
      title: 'Riviera 2025',
      role: 'Campus Decor Team',
      points: [
        'Designed & arranged visual décor elements',
        'Enhanced aesthetic appeal across spaces',
        'Worked closely with team to complete tasks',
      ],
    },
  ];

  return (
    <section id="experience" className="section-spacing" ref={ref}>
      <div className="container mx-auto px-8">
        <div className={`transition-all duration-700 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          <h2 className="font-heading text-3xl md:text-4xl text-accent mb-16 text-center">
            Experience
          </h2>

          <div className="max-w-3xl mx-auto relative">
            {/* Timeline line */}
            <div className="timeline-line ml-2" />

            {experiences.map((exp, index) => (
              <div
                key={exp.title}
                className="relative pl-10 pb-12 last:pb-0"
                style={{ transitionDelay: `${index * 150}ms` }}
              >
                {/* Timeline dot */}
                <div className="timeline-dot top-1" />

                <div className="elevated-card p-6">
                  <h3 className="font-heading text-xl text-accent mb-1">{exp.title}</h3>
                  <p className="text-secondary text-sm mb-4">{exp.role}</p>
                  <ul className="space-y-2">
                    {exp.points.map((point, idx) => (
                      <li key={idx} className="text-foreground/80 text-sm font-body flex items-start gap-3">
                        <span className="text-primary mt-1">•</span>
                        {point}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default ExperienceSection;
