import { useState, useEffect } from 'react';

const Navigation = () => {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { label: 'About', href: '#about' },
    { label: 'Skills', href: '#skills' },
    { label: 'Experience', href: '#experience' },
    { label: 'Contact', href: '#contact' },
  ];

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled ? 'bg-background/90 backdrop-blur-lg border-b border-border/50' : ''
      }`}
    >
      <div className="container mx-auto px-8">
        <div className="flex items-center justify-between h-16 md:h-20">
          <a href="#" className="font-heading text-lg text-accent">
            VB
          </a>

          <div className="hidden md:flex items-center gap-8">
            {navItems.map((item) => (
              <a
                key={item.label}
                href={item.href}
                className="link-underline text-sm text-foreground/70 hover:text-accent transition-colors font-body"
              >
                {item.label}
              </a>
            ))}
          </div>

          {/* Mobile menu button placeholder */}
          <button className="md:hidden text-accent">
            <span className="sr-only">Menu</span>
            <div className="w-5 h-px bg-accent mb-1" />
            <div className="w-5 h-px bg-accent" />
          </button>
        </div>
      </div>
    </nav>
  );
};

export default Navigation;
