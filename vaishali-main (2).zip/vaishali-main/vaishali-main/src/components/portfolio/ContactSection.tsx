import { Mail, Linkedin } from 'lucide-react';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';

const ContactSection = () => {
  const { ref, isVisible } = useScrollAnimation();

  const contacts = [
    { icon: Mail, label: 'Email', value: 'vaishalibalaji2006@gmail.com', href: 'mailto:vaishalibalaji2006@gmail.com' },
    { icon: Linkedin, label: 'LinkedIn', value: 'vaishali-balaji', href: 'https://www.linkedin.com/in/vaishali-balaji-297117334' },
  ];

  return (
    <section id="contact" className="section-spacing" ref={ref}>
      <div className="container mx-auto px-8">
        <div className={`transition-all duration-700 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          <h2 className="font-heading text-3xl md:text-4xl text-accent mb-16 text-center">
            Get in Touch
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-2xl mx-auto">
            {contacts.map((contact, index) => (
              <div
                key={contact.label}
                className={`elevated-card p-6 text-center transition-all duration-500 delay-${(index + 1) * 100}`}
                style={{ transitionDelay: `${index * 100}ms` }}
              >
                <contact.icon className="w-5 h-5 text-secondary mx-auto mb-4" />
                <p className="text-muted-foreground text-xs uppercase tracking-wider mb-2">
                  {contact.label}
                </p>
                {contact.href ? (
                  <a
                    href={contact.href}
                    target={contact.href.startsWith('http') ? '_blank' : undefined}
                    rel={contact.href.startsWith('http') ? 'noopener noreferrer' : undefined}
                    className="link-underline text-accent text-sm font-body"
                  >
                    {contact.value}
                  </a>
                ) : (
                  <p className="text-accent text-sm font-body">{contact.value}</p>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;
