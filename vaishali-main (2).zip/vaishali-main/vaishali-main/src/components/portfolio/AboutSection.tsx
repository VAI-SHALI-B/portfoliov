import { useScrollAnimation } from '@/hooks/useScrollAnimation';

const AboutSection = () => {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section id="about" className="section-spacing" ref={ref}>
      <div className="container mx-auto px-8">
        <div className={`max-w-3xl mx-auto transition-all duration-700 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          <h2 className="font-heading text-3xl md:text-4xl text-accent mb-12 text-center">
            About Me
          </h2>

          <div className="blush-card">
            <p className="text-foreground/90 leading-relaxed text-lg font-body font-light">
              I'm passionate about UI/UX design and frontend development, focusing on clean layouts, 
              balanced visual hierarchy, and smooth user flows. I love crafting digital experiences 
              that feel intuitive, organized, and aesthetically appealing. I'm also interested in 
              how AI/ML can enhance interaction design. My approach blends clarity, creativity, 
              and user-centered thinking.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
