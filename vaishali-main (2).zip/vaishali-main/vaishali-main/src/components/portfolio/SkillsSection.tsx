import { useScrollAnimation } from '@/hooks/useScrollAnimation';

const SkillsSection = () => {
  const { ref, isVisible } = useScrollAnimation();

  const skills = [
    'Critical thinking',
    'UI/UX designing',
    'Teamwork & collaboration',
    'Management & coordination',
    'Video editing',
    'Poster & content design',
    'Creativity & idea visualization',
  ];

  return (
    <section id="skills" className="section-spacing" ref={ref}>
      <div className="container mx-auto px-8">
        <div className={`transition-all duration-700 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          <h2 className="font-heading text-3xl md:text-4xl text-accent mb-12 text-center">
            Skills
          </h2>

          <div className="flex flex-wrap justify-center gap-4 max-w-3xl mx-auto">
            {skills.map((skill, index) => (
              <span
                key={skill}
                className="pill-tag"
                style={{ transitionDelay: `${index * 50}ms` }}
              >
                {skill}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default SkillsSection;
